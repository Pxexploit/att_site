<?php
session_start(); 

$mensagemacerto = "Faça o Login";
$texto = "";


if (isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'positivo') {
    $mensagemacerto = "Cadastro Realizado com sucesso!";

}else if((isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'LOG')){
    $mensagemacerto = "Usuário Desconectado!";
    session_destroy();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['botaosubmit'])) {
        $servername = "localhost";
        $username = "root"; 
        $password = ""; 
        $dbname = "sistema_login";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Falha na conexão: " . $conn->connect_error);
        }

        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $sql = "SELECT * FROM usuarios WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            
            $usuario = $result->fetch_assoc();

            if (password_verify($senha, $usuario['senha'])) {
              
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_senha'] = $usuario['senha'];
                $_SESSION['usuario_tipo'] = $usuario['tipo_usuario']; // Tipo de usuário (vendedor ou cliente)

             
                if ($_SESSION['usuario_tipo'] == 'vendedor') {
                    header("Location: siteVendedor.php"); // Página do vendedor
                } else {
                    header("Location: site.php"); // Página do cliente
                }
                exit();
            } else {
                $texto = "Senha incorreta!";
            }
        } else {
            $texto = "Usuário não encontrado!";
        }

        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styleslogin.css">
    <style>
       #mensagem {
            padding: 4px;
            color: rgba(196, 28, 28, 0.92);
        }
    </style>

     <!-- php para notificaçao usar no cadastro de produtos-->
   <?php
   /*
        if (isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'positivo') {
            echo "    
            <script>
                alert('" . $mensagemacerto . "');
            </script>" ;    
        }
        */
    ?>

</head>
<body>
<div class="container">
    <div id="mensagemdeubom"><?php echo $mensagemacerto; ?></div>

    <div class="form-container">
         <h2>Login de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
                <div id="mensagem"><?php echo $texto; ?></div>
            </div>

            <button type="submit" name="botaosubmit">Entrar</button>
            <p>Ainda não tem uma conta? <a href="register.php">Cadastre-se aqui.</a></p>
        </form>
    </div>
</div>

</body>
</html>
