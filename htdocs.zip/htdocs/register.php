<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="css/stylesregister.css">
    <style>
        #mensagemerro {
            padding: 4px;
            color: rgba(196, 28, 28, 0.92);
        }
    </style>
</head>
<body>

<?php
$erro = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['botaosubmit'])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "sistema_login";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Conexão falhou: " . $conn->connect_error);
        }
        $verif = "N";
   
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); 
        $tipo_usuario = $_POST['tipo_usuario'];

        $sql_check = "SELECT id FROM usuarios WHERE email = '$email'";
        $result = $conn->query($sql_check);

        if ($result->num_rows > 0) {
            $erro = "Este email já está registrado!";
        } else {
           
            $sql = "INSERT INTO usuarios (nome, email, senha, tipo_usuario) 
                    VALUES ('$nome', '$email', '$senha', '$tipo_usuario')";

            if ($conn->query($sql) === TRUE) {
                $erro = "Cadastro Realizado Com Sucesso!";
                $verif = "S";
                session_start();
                $_SESSION['deubom'] = 'positivo'; // Definir a sessão
                header("Location: ../login.php");                 
                exit; 
            } else {
                $erro = "Erro ao cadastrar usuário: " . $conn->error;
            }
        }

        $conn->close();
    }
}
?>

<div class="container">
    <div class="form-container">
        <h2>Cadastro de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
                <div id="mensagemerro"><?php 
                        echo $erro;               
                ?></div>
            </div>

        
            <div class="input-group">
                <label for="tipo_usuario">Tipo de Conta:</label>
                <select name="tipo_usuario" id="tipo_usuario" required>
                    <option value="cliente">Cliente</option>
                    <option value="vendedor">Vendedor</option>
                </select>
            </div>

            <button type="submit" name="botaosubmit">Cadastrar</button>
            <p>Já tem uma conta? <a href="login.php">Faça login aqui.</a></p>
        </form>
    </div>
</div>

</body>
</html>
