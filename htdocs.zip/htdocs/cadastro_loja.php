<?php
session_start();

// Verifica se o usuário está logado e se é vendedor
if (isset($_SESSION['usuario_email']) && isset($_SESSION['usuario_senha']) && isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] == 'vendedor') {

    // Verifica se o vendedor está tentando cadastrar a loja
    if (isset($_POST['cadastrar_loja'])) {
        $nome_loja = $_POST['nome_loja'];
        $descricao = $_POST['descricao'];

        // Conexão com o banco de dados
        $conn = new mysqli("localhost", "root", "", "sistema_login");

        if ($conn->connect_error) {
            die("Conexão falhou: " . $conn->connect_error);
        }

        // Verificar se o id_vendedor existe na tabela usuarios
        $id_vendedor = $_SESSION['usuario_id'];  // Usando o id armazenado na sessão

        // Verificar se o vendedor existe na tabela 'usuarios'
        $sql_check_vendedor = "SELECT id FROM usuarios WHERE id = '$id_vendedor' AND tipo = 'vendedor' LIMIT 1";
        $result = $conn->query($sql_check_vendedor);

        if ($result->num_rows > 0) {
            // O vendedor existe, podemos cadastrar a loja
            $sql = "INSERT INTO lojas (id_vendedor, nome_loja, descricao) VALUES ('$id_vendedor', '$nome_loja', '$descricao')";

            if ($conn->query($sql) === TRUE) {
                echo "Loja cadastrada com sucesso!";
            } else {
                echo "Erro ao cadastrar loja: " . $conn->error;
            }
        } else {
            // Caso o vendedor não exista ou o id_vendedor não seja válido
            echo "Erro: Vendedor não encontrado ou não autorizado a cadastrar loja.";
        }

        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Loja</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Link para o CSS -->
</head>
<body>

<header>
    <h1>Cadastrar Loja</h1>
    <a href="logout.php">Logout</a>
</header>

<section>
    <form action="cadastro_loja.php" method="POST">
        <label for="nome_loja">Nome da Loja:</label>
        <input type="text" id="nome_loja" name="nome_loja" required>
        
        <label for="descricao">Descrição da Loja:</label>
        <textarea id="descricao" name="descricao" required></textarea>
        
        <button type="submit" name="cadastrar_loja">Cadastrar Loja</button>
    </form>
</section>

</body>
</html>
<?php
} else {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
}
?>
